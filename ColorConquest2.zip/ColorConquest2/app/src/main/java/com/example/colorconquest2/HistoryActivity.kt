package com.example.colorconquest2

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class HistoryActivity : AppCompatActivity() {

    private lateinit var historyListView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        historyListView = ListView(this)
        setContentView(historyListView)

        val sharedPreferences = getSharedPreferences("game_prefs", MODE_PRIVATE)

        val gameHistory = loadGameHistory(sharedPreferences)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, gameHistory)
        historyListView.adapter = adapter
    }

    private fun loadGameHistory(sharedPreferences: SharedPreferences): List<String> {
        val gameHistory = mutableListOf<String>()
        for (i in 0..9) {
            val gameDetails = sharedPreferences.getString("game_$i", null)
            gameDetails?.let { gameHistory.add(it) }
        }
        return gameHistory
    }
}
