package com.example.colorconquest2

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

class HomeActivity : AppCompatActivity() {

    private lateinit var winRecord: TextView
    private lateinit var sharedPreferences: SharedPreferences
    private var playerOneWins = 0
    private var playerTwoWins = 0
    private var gridSize = 5
    private var matchCount = 3
    private var playerCount = 2
    private var boardStyle = "Classic"
    private var isDarkMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("TAG", "onCreate")

        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(32, 32, 32, 32)

        winRecord = TextView(this)
        winRecord.textSize = 18f
        layout.addView(winRecord)

        val gridSizes = arrayOf("3x3", "4x4", "5x5", "6x6", "7x7")
        val gridSizeSpinner = createSpinner(gridSizes)
        layout.addView(gridSizeSpinner)

        val matchCounts = arrayOf("Best of 3", "Best of 5", "Best of 7")
        val matchCountSpinner = createSpinner(matchCounts)
        layout.addView(matchCountSpinner)

        val playerCounts = arrayOf("2 Players", "3 Players", "4 Players")
        val playerCountSpinner = createSpinner(playerCounts)
        layout.addView(playerCountSpinner)

        val boardStyles = arrayOf("Classic", "Modern", "Neon")
        val boardStyleSpinner = createSpinner(boardStyles)
        layout.addView(boardStyleSpinner)

        val themeSwitch = Switch(this)
        themeSwitch.text = "Dark Mode"
        layout.addView(themeSwitch)

        val startGameButton = Button(this)
        startGameButton.text = "Start Game"
        layout.addView(startGameButton)

        val hackerModeButton = Button(this)
        hackerModeButton.text = "Hacker Mode"
        layout.addView(hackerModeButton)

        val historyButton = Button(this)
        historyButton.text = "Game History"
        layout.addView(historyButton)

        sharedPreferences = getSharedPreferences("game_prefs", MODE_PRIVATE)
        playerOneWins = sharedPreferences.getInt("playerOneWins", 0)
        playerTwoWins = sharedPreferences.getInt("playerTwoWins", 0)
        isDarkMode = sharedPreferences.getBoolean("isDarkMode", false)
        updateWinRecord()
        applyTheme()

        setContentView(layout)

        gridSizeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                gridSize = parent.getItemAtPosition(position).toString().split("x")[0].toInt()
                Log.i("TAG", "1")
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        matchCountSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                matchCount = parent.getItemAtPosition(position).toString().split(" ")[2].toInt()
                Log.i("TAG", "2")
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        playerCountSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                playerCount = parent.getItemAtPosition(position).toString().split(" ")[0].toInt()
                Log.i("TAG", "3")
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        boardStyleSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                boardStyle = parent.getItemAtPosition(position).toString()
                Log.i("TAG", "4")
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        themeSwitch.isChecked = isDarkMode
        themeSwitch.setOnCheckedChangeListener { _, isChecked ->
            isDarkMode = isChecked
            sharedPreferences.edit().putBoolean("isDarkMode", isDarkMode).apply()
            applyTheme()
            Log.i("TAG", "5")
        }

        startGameButton.setOnClickListener {
            startActivity(Intent(this@HomeActivity, MainActivity::class.java))
            Log.i("TAG", "6")
        }

        hackerModeButton.setOnClickListener {
            val intent = Intent(this@HomeActivity, MainActivity::class.java)
            intent.putExtra("gridSize", gridSize)
            intent.putExtra("matchCount", matchCount)
            intent.putExtra("playerCount", playerCount)
            intent.putExtra("boardStyle", boardStyle)
            intent.putExtra("isHackerMode", true)
            startActivity(intent)
            Log.i("TAG", "7")
        }

        historyButton.setOnClickListener {
            startActivity(Intent(this@HomeActivity, HistoryActivity::class.java))
            Log.i("TAG", "8")
        }
    }

    private fun createSpinner(items: Array<String>): Spinner {
        val spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        Log.i("TAG", "9")
        return spinner
    }

    private fun updateWinRecord() {
        val record = "Player 1 Wins: $playerOneWins | Player 2 Wins: $playerTwoWins"
        winRecord.text = record
        Log.i("TAG", "10")
    }

    fun incrementPlayerOneWins() {
        playerOneWins++
        sharedPreferences.edit().putInt("playerOneWins", playerOneWins).apply()
        updateWinRecord()
        Log.i("TAG", "11")
    }

    fun incrementPlayerTwoWins() {
        playerTwoWins++
        sharedPreferences.edit().putInt("playerTwoWins", playerTwoWins).apply()
        updateWinRecord()
        Log.i("TAG", "12")
    }

    private fun applyTheme() {
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        Log.i("TAG", "13")
    }
}
