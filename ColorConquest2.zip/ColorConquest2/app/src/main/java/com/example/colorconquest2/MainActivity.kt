package com.example.colorconquest2

import android.content.DialogInterface
import android.content.SharedPreferences
import android.graphics.Color
import android.media.MediaPlayer
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Vibrator
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var gridLayout: GridLayout
    private lateinit var progressBar: ProgressBar
    private var playerOneTurn = true
    private var gridSize = 5
    private var board = mutableMapOf<String, Int>()
    private var scores = mutableMapOf<String, Int>()
    private var cells = mutableMapOf<String, TextView>()
    private var timer: CountDownTimer? = null
    private var currentProgress = 100
    private lateinit var sharedPreferences: SharedPreferences
    private var matchCount = 3
    private var currentMatch = 1
    private var playerOneWins = 0
    private var playerTwoWins = 0
    private var playerCount = 2
    private var boardStyle = "Classic"
    private lateinit var mediaPlayer: MediaPlayer
    private lateinit var vibrator: Vibrator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        gridSize = intent.getIntExtra("gridSize", 5)
        matchCount = intent.getIntExtra("matchCount", 3)
        playerCount = intent.getIntExtra("playerCount", 2)
        boardStyle = intent.getStringExtra("boardStyle") ?: "Classic"

        val mainLayout = LinearLayout(this)
        mainLayout.orientation = LinearLayout.VERTICAL
        mainLayout.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )

        gridLayout = GridLayout(this)
        gridLayout.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            0,
            1f
        )
        mainLayout.addView(gridLayout)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 100
        progressBar.progress = currentProgress
        mainLayout.addView(progressBar)

        val resetButton = Button(this)
        resetButton.text = "Reset"
        mainLayout.addView(resetButton)

        setContentView(mainLayout)

        sharedPreferences = getSharedPreferences("game_prefs", MODE_PRIVATE)

        // mediaPlayer = MediaPlayer.create(this, R.raw.click_sound)
        vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator

        initializeBoard()

        resetButton.setOnClickListener { resetGame() }

        startTimer()
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    private fun initializeBoard() {
        Log.i("MAIN", "Initializing board")
        gridLayout.removeAllViews()
        gridLayout.columnCount = gridSize
        gridLayout.rowCount = gridSize

        val cellSize = dpToPx(60) // Define a cell size in dp (e.g., 60dp)

        for (i in 0 until gridSize) {
            for (j in 0 until gridSize) {
                val cell = TextView(this)
                cell.setBackgroundColor(getBoardStyleColor())
                cell.textSize = 24f
                cell.gravity = Gravity.CENTER

                val params = GridLayout.LayoutParams()
                params.width = cellSize
                params.height = cellSize
                params.rowSpec = GridLayout.spec(i, 1f)
                params.columnSpec = GridLayout.spec(j, 1f)
                cell.layoutParams = params

                cell.setOnClickListener { handleCellClick(cell, i, j) }
                val cellId = "$i$j"
                board[cellId] = 0
                scores[cellId] = 0
                cells[cellId] = cell

                gridLayout.addView(cell)
            }
        }
    }

    private fun getBoardStyleColor(): Int {
        return when (boardStyle) {
            "Modern" -> Color.DKGRAY
            "Neon" -> Color.MAGENTA
            else -> Color.LTGRAY
        }
    }

    private fun handleCellClick(cell: TextView, row: Int, col: Int) {
        Log.i("MAIN", "Cell clicked: $row, $col")
        val cellId = "$row$col"
        var score = scores[cellId]!!

        if (board[cellId] == 0) {
            cell.setBackgroundColor(if (playerOneTurn) Color.RED else Color.BLUE)
            score += 3
            board[cellId] = if (playerOneTurn) 1 else 2
        } else if (board[cellId] == if (playerOneTurn) 1 else 2) {
            score += 1
        } else {
            playWrongClickFeedback()
            return
        }

        scores[cellId] = score
        cell.text = score.toString()

        if (score >= 4) {
            expand(cellId, if (playerOneTurn) 1 else 2)
        }

        playerOneTurn = !playerOneTurn
        resetTimer()

        if (playerCount > 2 && !playerOneTurn) {
            handleComputerTurn()
        }
    }

    private fun handleComputerTurn() {
        // Implement basic AI for computer's turn here.
    }

    private fun expand(cellId: String, player: Int) {
        val (row, col) = cellId.split("_").map { it.toInt() }

        scores[cellId] = 0
        cells[cellId]!!.setBackgroundColor(Color.LTGRAY)
        cells[cellId]!!.text = ""

        val directions = arrayOf(intArrayOf(-1, 0), intArrayOf(1, 0), intArrayOf(0, -1), intArrayOf(0, 1))
        for (direction in directions) {
            val newRow = row + direction[0]
            val newCol = col + direction[1]
            val newCellId = "$newRow$newCol"
            if (newRow in 0 until gridSize && newCol in 0 until gridSize) {
                if (board[newCellId] != player) {
                    board[newCellId] = player
                    scores[newCellId] = 1
                    cells[newCellId]!!.setBackgroundColor(if (player == 1) Color.RED else Color.BLUE)
                    cells[newCellId]!!.text = "1"
                } else {
                    val newScore = scores[newCellId]!! + 1
                    scores[newCellId] = newScore
                    cells[newCellId]!!.text = newScore.toString()
                    if (newScore >= 4) {
                        expand(newCellId, player)
                    }
                }
                animateCell(cells[newCellId]!!)
                playPowerUpFeedback()
            }
        }
    }

    private fun animateCell(view: View) {
        view.animate().alpha(0.0f).setDuration(500).withEndAction { view.animate().alpha(1.0f).setDuration(500) }.start()
    }

    private fun startTimer() {
        timer = object : CountDownTimer(30000, 300) {
            override fun onTick(millisUntilFinished: Long) {
                currentProgress -= 1
                progressBar.progress = currentProgress
            }

            override fun onFinish() {
                showGameOverDialog(if (playerOneTurn) "Player 2" else "Player 1")
            }
        }.start()
    }

    private fun resetTimer() {
        timer?.cancel()
        currentProgress = 100
        progressBar.progress = currentProgress
        startTimer()
    }

    private fun showGameOverDialog(winner: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Game Over")
        builder.setMessage("$winner wins this match!")
        builder.setPositiveButton("OK") { _: DialogInterface?, _: Int ->
            if (winner == "Player 1") {
                playerOneWins++
            } else {
                playerTwoWins++
            }

            currentMatch++
            if (currentMatch > matchCount || playerOneWins > matchCount / 2 || playerTwoWins > matchCount / 2) {
                val overallWinner = if (playerOneWins > playerTwoWins) "Player 1" else "Player 2"
                val finalBuilder = AlertDialog.Builder(this@MainActivity)
                finalBuilder.setTitle("Series Over")
                finalBuilder.setMessage("$overallWinner wins the series!")
                finalBuilder.setPositiveButton("OK") { _: DialogInterface?, _: Int ->
                    val homeActivity = HomeActivity()
                    if (overallWinner == "Player 1") {
                        homeActivity.incrementPlayerOneWins()
                    } else {
                        homeActivity.incrementPlayerTwoWins()
                    }
                    finish()
                }
                finalBuilder.show()
            } else {
                resetGame()
            }
        }
        builder.show()
    }

    private fun resetGame() {
        for (cell in cells.values) {
            cell.setBackgroundColor(Color.LTGRAY)
            cell.text = ""
        }
        board.clear()
        scores.clear()
        initializeBoard()
        playerOneTurn = true
        resetTimer()
    }

    private fun playWrongClickFeedback() {
        vibrator.vibrate(200)
        mediaPlayer.start()
    }

    private fun playPowerUpFeedback() {
        vibrator.vibrate(100)
        mediaPlayer.start()
    }
}
